<?php
return[
"form_title" => "Detailed search",
"form_city_placeholder" => "Where would you like to rent real estate?",
"form_type_placeholder" => "Choose type of the property",
"form_price_range" => "Price range:",
"form_number_of_guests" => "NUMBER OF GUESTS",
"form_search" => "SEARCH",
//////////////////////////////////////////////////////////////////////////////////////////////////////
"page_heading" => "Results around",
"no_properties" => "Sorry, there are no properties",
]
?>