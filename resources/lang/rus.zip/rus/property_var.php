<?php
return[
"click_here" => "Click here to see all fascilities / amenities.",
"property_description" => "Property Description",
"terms_and_cond" => "Terms and Conditions",
"night" => "night",
"check_in" => "CHECK-IN",
"checkout" => "CHECKOUT",
"guests" => "Guests",
"book_your_property" => "BOOK YOUR PROPERTY",
"book_through_email" => "Book your stay through email",
"step_back" => "step back",
"just_one_more" => "Just one more step and you are done. Afterwards, we will contact you back.",
//////////////////////////////
"form_name" => "NAME",
"form_surname" => "SURNAME",
"form_phone" => "PHONE NUMBER",
"form_email" => "E-MAIL",
"form_send" => "SEND INQURY",
"form_send_p" => "Our representative will contact you back through e-mail with the confirmation as soon as possible.",
///////////////////////////////
"google_maps_location" => "Google maps location",
"more_like_this" => "More like this",
"covid_19" => "Review COVID-19 travel restrictions before you book.",
"learn_more" => "Learn more",
///////////////////////////////
"no_specials" => "Sorry, there are no special properties",



]
?>