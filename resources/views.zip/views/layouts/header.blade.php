<div class="header">

        <div class="header2 ">
        <nav class="navbar navbar-expand-lg navbar-light bg-transparent">
          <a class="navbar-brand" href="/"><img src="/assets/images/logo1.png" alt=""></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto ml-auto my-2">
            <li class="nav-item dropdown">
                <a class="nav-link " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <h5>  Tourist Corner</h5>
                </a>
                <div class="dropdown-menu " aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="/rent-a-car"><h5>Car rental</h5></a>
                  <a class="dropdown-item" href="/rent-a-yacht"><h5>Yacht rental</h5></a>
                   <a class="dropdown-item" href="/excoursions"><h5>Excursions</h5></a>
                 <a class="dropdown-item" href="/transfers"><h5>Transfers</h5></a>

                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/rentProperty"><h5>Rent property</h5></a>
              </li>
              <li class="nav-item active">
                <a class="nav-link" href="/news"><h5>News</h5></a>
              </li>
           
            
            </ul>
            <ul class="navbar-nav ml-auto">
              <li class="nav-item ">
                <a class="nav-link" href="/about"><h5>About us </h5></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#"><h5>Contact us</h5></a>
              </li>

             <!--  <li class="nav-item vipLink">
                <a class="nav-link " href="#"><h5>VIP Club</h5></a>
              </li> -->
            </ul>
          </div>
        </nav>
    </div>
  </div>
