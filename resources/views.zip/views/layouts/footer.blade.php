<footer class="">

    <div class="footer1 row paddinglra mx-0">
        <div class="col-3">
            <ul class="list-unstyled footerLista">
                <li>
                    <h4>OUR SERVICES</h4>
                </li>
                <li>
                    <a target="_blank" href="#">VIP</a>
                </li>
                <li>
                    <a target="_blank" href="#"> Car rental</a>
                </li>
                <li>
                    <a target="_blank" href="#"> Yacht rental</a>
                </li>
                <li>
                    <a target="_blank" href="#">Transfers</a>
                </li>
                <li>
                    <a target="_blank" href="#"> Excursions </a>
                </li>


            </ul>
        </div>
        <div class="col-3">
            <ul class="list-unstyled footerLista">
                <li>
                    <h4>INFORMATION </h4>
                </li>
                <li>
                    <div class="d-flex">
                        <div > <p class="bold"> Adress :</p></div>
                        <div>
                            <p>Adress 1, Budva, Montenegro</p>
                            <p> Adress 2, Moskow, Russia</p>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="d-flex">
                        <div><p class="bold"> Telefon:</p></div>
                        <div>+382 00 000 000</div>
                    </div>
                </li>
                <li>
                    <div class="d-flex">
                        <div><p class="bold"> Email adresa:</p></div>
                        <div>email@cmm.me</div>
                    </div>
                </li>
            


            </ul>
        </div>
        <div class="col-3">
            <ul class="list-unstyled footerLista">
                <li>
                    <h4>USEFUL LINKS</h4>
                </li>
                <li>
                    <a target="_blank" href="#">Ministery of Economy</a>
                </li>
                <li>
                    <a target="_blank" href="#">Ministery of Finance </a>
                </li>
                 <li>
                    <ul>
                        <li class="bold">Facebook</li>
                        <li class="bold">Instagram</li>
                        <li class="bold">Twitter</li>
                    </ul>
                </li>

            </ul>
        </div>
        <div class="col-3">
            <ul class="list-unstyled footerLista">
                <li>
                    <h4>LAST BLOGS</h4>
                </li>
                <li>
                    <a target="_blank" href="#">Blogpost 1</a>
                </li>
                <li>
                    <a target="_blank" href="#">Blogpost 1</a>
                </li>    <li>
                    <a target="_blank" href="#">Blogpost 1</a>
                </li>    <li>
                    <a target="_blank" href="#">Blogpost 1</a>
                </li>    <li>
                    <a target="_blank" href="#">Blogpost 1</a>
                </li>    <li>
                    <a target="_blank" href="#">Blogpost 1</a>
                </li>

            </ul>
        </div>

    </div>

    <div class="footer2">
        <div class="left_footer">
            <p>All rights - CMM</p>
        </div>
        <div class="right_footer">
            <p>Made by QQRIQ</p>
        </div>
    </div>


</footer>
