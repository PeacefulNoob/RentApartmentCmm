<div class="header">

        <div class="header2 ">
        <nav class="navbar navbar-expand-lg navbar-light bg-transparent">
        <a class="nav-link navbar-brand mobile " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <h5>  Tourist</h5>  <h5>Corner</h5>  
                </a>
                <div class="dropdown-menu " aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="/{{app()->getLocale()}}/rent-a-car"><h5>Car rental</h5></a>
                  <a class="dropdown-item" href="/{{app()->getLocale()}}/rent-a-yacht"><h5>Yacht rental</h5></a>
                   <a class="dropdown-item" href="/{{app()->getLocale()}}/excoursions"><h5>Excursions</h5></a>
                 <a class="dropdown-item" href="/{{app()->getLocale()}}/transfers"><h5>Transfers</h5></a>

                </div>
          <a class="navbar-brand" href="/{{app()->getLocale()}}/"><img src="/assets/images/logo1.png" alt=""></a>
          <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="sr-only">Toggle navigation</span>
               
                <span class="icon-bar top-bar"></span>
                <span class="icon-bar middle-bar"></span>
                <span class="icon-bar bottom-bar"></span>
              </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto ml-auto my-2">
            <li class="nav-item dropdown desktop">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Tourist Corner

                </a><span class="caret"></span>
                <div class="dropdown-menu " aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="/{{app()->getLocale()}}/rent-a-car"><h5>Car rental</h5></a>
                  <a class="dropdown-item" href="/{{app()->getLocale()}}/rent-a-yacht"><h5>Yacht rental</h5></a>
                   <a class="dropdown-item" href="/{{app()->getLocale()}}/excoursions"><h5>Excursions</h5></a>
                 <a class="dropdown-item" href="/{{app()->getLocale()}}/transfers"><h5>Transfers</h5></a>

                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/{{app()->getLocale()}}/rentProperty"><h5>Rent property</h5></a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="/{{app()->getLocale()}}/news"><h5>News</h5></a>
              </li>
              <li class="nav-item ">
                <a class="nav-link" href="https://www.cmm-montenegro.com/" target="_blank"><h5> Properties for sale</h5></a>
              </li> 
            
            </ul>
            <ul class="navbar-nav ml-auto">
              <li class="nav-item ">
                <a class="nav-link" href="/{{app()->getLocale()}}/about"><h5>About us </h5></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="/{{app()->getLocale()}}/about#about_contact"><h5>Contact us</h5></a>
              </li>
              @foreach (config('app.languages') as $locale)
                 
                 <li class="nav-item">
                     <a class="nav-link"
                        href="{{ route('setLocaleRout', $locale) }}"
                         @if (app()->getLocale() == $locale) style="font-weight: bold; text-decoration: underline" @endif>{{ strtoupper($locale) }}</a>
                 </li> 
             @endforeach
            </ul>
       
          </div>
        </nav>
    </div>
  </div>
