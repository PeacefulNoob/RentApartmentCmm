@extends('layouts.master')
@section('content')
<div class="homeMain">
<div class="terms padding row m-0">
<h1>Terms n Conditions</h1>
</div>
</div>

@endsection
