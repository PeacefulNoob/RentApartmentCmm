@extends('layouts.master')

@section('content')
<div style="height: 500px;">

</div>
@endsection
