<?php
return[
"page_title" => "Excoursions in Montenegro",
"page_title_p" => "There is a huge number of attractions In Montenegro that are worth visiting. When booking a tour from people on the street, you can’t be sure that you will receive a good service, and even more important than that, you can’t be sure that you get your money back for waste of time when excursion is poorly organized.",
"page_title_p2" => "When booking tours with us, you are always sure in the service you are going to get. You can order an individual tour in a comfortable car with a guide or book a group tour, and make a little trip with a small pleasant company. All our cars are new, air-conditioned, we have professional and proven drivers, our guides – they are people who know everything about Montenegro!",
"cetinje" => "Cetinje and Mountain Lovćen",
"dubrovnik" => "Dubrovnik",
"kotor" => "Kotor",
"ostrog" => "Monastery Ostrog",
"skadar_lake" => "Skadar lake"
]
?>