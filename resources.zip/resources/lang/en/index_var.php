<?php
return[
    "location" => "Location",
    "property_type" => "Property type",
    "how_guests" => "How many guests",

"button_go" => "GO!",
"hero_mobile1" => "Rent a real estate",
"hero_mobile2" => "in Montenegro",
"hero_desktop" => "Rent a real estate in Montenegro",
"form_p1" => "Where would you like to rent real estate?",
"our_favourite_title" => "Our favourites",
"covid_section" => "Review COVID-19 travel restrictions before you book.",
"learn_more" => "Learn more",
"property_title" => "Sorry, there are no special properties",
"about_mne" => "About Montenegro",
"about_mne_p1" => "Events / Festivals / Parties / Holidays",
]
?>

