<?php
return[

"news_title" => "ABOUT MONTENEGRO",

"news_title_p" => "Events / Festivals / Parties / Holidays",

"faq_title" => "Frequently asked Questions",
"more_rec_news" => "More recommended news :",


]
?>